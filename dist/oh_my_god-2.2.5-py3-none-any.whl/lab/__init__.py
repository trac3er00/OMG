"""Lab package for OMG."""
