"""Registry package for OMG."""
