"""OMG agents module."""
